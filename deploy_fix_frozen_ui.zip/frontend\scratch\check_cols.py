import urllib.request
import csv
import io
import json
import sys

# Force UTF-8 for output
sys.stdout.reconfigure(encoding='utf-8')

SHEET_ID = "1Y6ty2RlGYh7Zpo4V1xOUQChyag1p15FvyxBQNaaPlCk"
GID = "0" # GTC
url = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/export?format=csv&gid={GID}"

try:
    with urllib.request.urlopen(url) as response:
        content = response.read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        cols = reader.fieldnames
        first_row = next(reader)
        
        result = {
            "columns": cols,
            "sample": first_row
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
except Exception as e:
    print(f"Error: {e}")
