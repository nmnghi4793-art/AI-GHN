import json
import sys

transcript_path = r"C:\Users\Admin\.gemini\antigravity-ide\brain\dd821a64-2ea7-46cd-8d88-a84c0b95ea04\.system_generated\logs\transcript.jsonl"
output_path = r"C:\Users\Admin\.gemini\antigravity\scratch\ghn_dashboard\scratch\user_requests.txt"

with open(transcript_path, "r", encoding="utf-8") as f_in, open(output_path, "w", encoding="utf-8") as f_out:
    for line in f_in:
        try:
            data = json.loads(line)
            if data.get("type") == "USER_INPUT":
                f_out.write("="*40 + "\n")
                f_out.write(f"Step: {data.get('step_index')}\n")
                f_out.write(f"Content:\n{data.get('content')}\n")
        except Exception as e:
            pass
print("Done extracting user requests!")
