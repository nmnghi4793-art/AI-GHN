import os, json, urllib.request, csv, io

SHEET_ID = "1Y6ty2RlGYh7Zpo4V1xOUQChyag1p15FvyxBQNaaPlCk"
url = f"https://docs.google.com/spreadsheets/d/{SHEET_ID}/gviz/tq?tqx=out:csv&sheet=Xe%20Daily%20Logs"

try:
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=10) as resp:
        content = resp.read().decode('utf-8')
        reader = csv.DictReader(io.StringIO(content))
        rows = list(reader)
        print("GViz CSV fetch successful! Row count:", len(rows))
        if rows:
            print("Headers:", list(rows[0].keys()))
            print("Sample 1:", rows[0])
except Exception as e:
    print("GViz CSV fetch failed:", e)
