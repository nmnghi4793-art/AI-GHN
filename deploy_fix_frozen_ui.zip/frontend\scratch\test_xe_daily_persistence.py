import os, sys, json
sys.path.insert(0, '.')

from main import _load_xe_daily_records, _save_xe_daily_records

records = _load_xe_daily_records()
print("1. Records loaded at startup:", len(records))
assert len(records) == 30, f"Expected 30 records, got {len(records)}"

# Test adding a record
test_record = {
    "id": "test9999",
    "ngay": "22/07/2026",
    "ten_kho": "Kho Giao Hàng Nặng - Vinh - Nghệ An",
    "loai": "Xe tăng cường",
    "so_luong_xe": 1,
    "bien_so_xe": "37C-999.99",
    "ten_ncc": "Test Vendor",
    "trong_tai": 2500,
    "ghi_chu": "Unit test record",
    "nguoi_nhap": "Unit Test",
    "thoi_gian_ghi_nhan": "2026-07-22T10:00:00Z"
}

records.append(test_record)
saved_ok = _save_xe_daily_records(records, sync_db=False)
print("2. Save status:", saved_ok)

# Simulate container restart: read again
reloaded = _load_xe_daily_records()
print("3. Records reloaded after simulated restart:", len(reloaded))
assert len(reloaded) == 31, f"Expected 31 records, got {len(reloaded)}"

# Cleanup test record
reloaded = [r for r in reloaded if r.get("id") != "test9999"]
_save_xe_daily_records(reloaded, sync_db=False)
final_check = _load_xe_daily_records()
print("4. Records count after cleanup:", len(final_check))
assert len(final_check) == 30, f"Expected 30 records, got {len(final_check)}"

print("ALL PERSISTENCE TESTS PASSED 100%!")
