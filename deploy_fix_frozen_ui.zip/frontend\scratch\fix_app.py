import sys
import re

with open('app.js', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Update getNsWorst in assembleTelegramReport
new_ns_report_logic = """    function getNsWorst(days, label, minVol) {
        const allDates = [...new Set(state.nangSuatData.map(r => r['Ngày']).filter(Boolean))].sort((a,b) => parseVN(b) - parseVN(a));
        if (!allDates.length) return `*${label}:*\\n_Trống_\\n`;
        
        const latestTs = parseVN(allDates[0]);
        let filtered = [];
        
        if (days === 1) {
            filtered = state.nangSuatData.filter(r => r['Ngày'] === allDates[0]);
        } else {
            const cutoff = latestTs - (days * 24 * 60 * 60 * 1000);
            filtered = state.nangSuatData.filter(r => parseVN(r['Ngày']) >= cutoff);
        }
        
        const map = {};
        filtered.forEach(r => {
            const id = r['driver']; if (!id) return;
            if (!map[id]) map[id] = { name: id, prov: r['to_province_name'], vol: 0, succ: 0 };
            const v = parseInt(r['volume']||0);
            map[id].vol += v;
            map[id].succ += (parsePct(r['Tỉ lệ GTC'])/100) * v;
        });
        
        const list = Object.values(map)
            .map(d => ({ ...d, pct: d.vol > 0 ? (d.succ/d.vol*100) : 0 }))
            .filter(d => d.vol >= minVol)
            .sort((a,b) => a.pct - b.pct)
            .slice(0, 5);
            
        let res = `*${label}:*\\n`;
        list.forEach(d => res += `• ${d.name} (${d.prov}): *${d.pct.toFixed(1)}%* (${d.vol} đơn)\\n`);
        if (list.length === 0) res += `_Trống_\\n`;
        return res;
    }

    msg += getNsWorst(1, "Ngày gần nhất", 30);
    msg += "\\n" + getNsWorst(7, "Tuần gần nhất", 30);
    msg += "\\n" + getNsWorst(30, "Tháng gần nhất", 30);"""

pattern_ns_report = r'    function getNsWorst.*?msg \+= "\\n" \+ getNsWorst\(30, "Tháng gần nhất", 30\);'
content = re.sub(pattern_ns_report, new_ns_report_logic, content, flags=re.DOTALL)

# 2. Update renderNangSuatSection (minVol and sorting)
content = content.replace("const minVol = currentNsPeriod === 'day' ? 5 : 30;", "const minVol = 30;")
content = content.replace("filteredData.sort((a,b) => parseVN(b['Ngày']) - parseVN(a['Ngày']))", 
                          "filteredData.sort((a,b) => { const rA = parsePct(a['Tỉ lệ GTC']), rB = parsePct(b['Tỉ lệ GTC']); if(rB !== rA) return rB - rA; return parseVN(b['Ngày']) - parseVN(a['Ngày']); })")

with open('app.js', 'w', encoding='utf-8') as f:
    f.write(content)
print("Done")
