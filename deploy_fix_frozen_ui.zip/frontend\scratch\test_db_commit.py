import sys, os, json, secrets
from datetime import datetime

sys.path.insert(0, '.')

from main import get_xe_van_hanh_records, save_xe_van_hanh_records, import_xe_van_hanh_records, _load_xe_daily_records, _save_xe_daily_records, MASTER_30_XE_DAILY_RECORDS, XE_DAILY_META_FILE

# 1. Reset dataset to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
if os.path.exists(XE_DAILY_META_FILE):
    os.remove(XE_DAILY_META_FILE)

# 2. Check initial history
init_res = get_xe_van_hanh_records()
print("1. Initial record count:", init_res["total"])
assert init_res["total"] == 30

# 3. Test Manual Save of 1 Xe OFF
class DummyRequest:
    def __init__(self, data):
        self._data = data
    async def json(self):
        return self._data

import asyncio
loop = asyncio.get_event_loop()

rec_off = {
  "date": "23/07/2026",
  "warehouse": "Kho Giao Hàng Nặng - Tam Kỳ - Quảng Nam",
  "recordType": "Xe không hoạt động",
  "vehicleCount": 1,
  "licensePlate": "92C-111.22",
  "vendor": "Giao Hàng Nặng",
  "payloadKg": 1400,
  "note": "Bị hỏng lốp"
}

res_save1 = loop.run_until_complete(save_xe_van_hanh_records(DummyRequest(rec_off)))
print("2. Save 1 Xe OFF response:", json.dumps(res_save1, ensure_ascii=False))
assert res_save1["success"] is True
assert res_save1["savedCount"] == 1
assert res_save1["totalRecords"] == 31

# 4. Test Manual Save of 1 Xe Tăng Cường
rec_tc = {
  "date": "23/07/2026",
  "warehouse": "Kho Giao Hàng Nặng - Đà Nẵng",
  "recordType": "Xe tăng cường",
  "vehicleCount": 2,
  "licensePlate": "43C-999.88",
  "vendor": "Bảo Châu Phát",
  "payloadKg": 2500,
  "note": "Quá tải ca 1"
}

res_save2 = loop.run_until_complete(save_xe_van_hanh_records(DummyRequest(rec_tc)))
print("3. Save 1 Xe TC response:", json.dumps(res_save2, ensure_ascii=False))
assert res_save2["success"] is True
assert res_save2["savedCount"] == 1
assert res_save2["totalRecords"] == 32

# 5. Check History API after 2 saves
history_res = get_xe_van_hanh_records()
print("4. History API count after 2 saves:", history_res["total"])
assert history_res["total"] == 32

# Clean up
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
final_res = get_xe_van_hanh_records()
print("5. Cleaned up history count:", final_res["total"])
assert final_res["total"] == 30

print("\nALL DATABASE COMMIT & VERIFICATION TESTS PASSED 100%!")
