import sys, os, json

sys.path.insert(0, '.')
from main import get_xe_van_hanh_meta, get_kho_gxt

meta = get_xe_van_hanh_meta(force=True)

warehouses = meta.get("warehouses", [])
print(f"1. Total warehouses loaded in meta: {len(warehouses)}")
assert len(warehouses) == 25, f"Expected 25 warehouses, got {len(warehouses)}"

print("\nSample 5 Warehouses (ID & Label):")
for w in warehouses[:5]:
    print(f" - ID: {w['id']} | Name: {w['name']}")
    assert w["id"], "Warehouse ID cannot be empty"
    assert w["name"].startswith("Kho Giao Hàng Nặng"), f"Label format invalid: {w['name']}"

print(f"\n2. Total NCC loaded: {len(meta.get('ncc_all', []))}")
print("NCC List:", meta.get('ncc_all', []))

print("\nFORM META & 25 KHO ID TEST PASSED 100%!")
