import sys, os, json, secrets
from datetime import datetime

sys.path.insert(0, '.')

from main import get_xe_van_hanh_records, save_xe_van_hanh_records, import_xe_van_hanh_records, _load_xe_daily_records, _save_xe_daily_records, MASTER_30_XE_DAILY_RECORDS, XE_DAILY_META_FILE

# 1. Reset dataset to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
if os.path.exists(XE_DAILY_META_FILE):
    os.remove(XE_DAILY_META_FILE)

# 2. Check initial history API response
init_res = get_xe_van_hanh_records()
print("1. Initial GET /api/xe-van-hanh/records count:", init_res["total"])
assert init_res["total"] == 30, f"Expected 30, got {init_res['total']}"

# 3. Save 1 record via POST API
class DummyRequest:
    def __init__(self, data):
        self._data = data
    async def json(self):
        return self._data

import asyncio
loop = asyncio.get_event_loop()

test_rec = {
  "date": "23/07/2026",
  "warehouse": "Kho Giao Hàng Nặng - Tam Kỳ - Quảng Nam",
  "recordType": "Xe tăng cường",
  "vehicleCount": 1,
  "licensePlate": "43C-888.99",
  "vendor": "Giao Hàng Nặng",
  "payloadKg": 2500
}

save_res = loop.run_until_complete(save_xe_van_hanh_records(DummyRequest(test_rec)))
print("2. Save Record Response:", save_res)
assert save_res["success"] is True

# 4. Check GET history API after save
after_res = get_xe_van_hanh_records()
print("3. GET /api/xe-van-hanh/records count after 1 save:", after_res["total"])
assert after_res["total"] == 31, f"Expected 31, got {after_res['total']}"

# Verify latest record is our newly added record
latest = after_res["data"][0]
print("4. Latest record in history:", latest["id"], "| Kho:", latest["ten_kho"], "| Xe:", latest["bien_so_xe"])
assert latest["bien_so_xe"] == "43C-888.99"

# 5. Clean up test records back to 30
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
final_res = get_xe_van_hanh_records()
print("5. Cleaned up GET history count:", final_res["total"])
assert final_res["total"] == 30

print("\nALL HISTORY REFRESH TESTS PASSED 100%!")
