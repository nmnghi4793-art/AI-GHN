import os
import sys
import asyncio
import datetime as dt

# Thêm thư mục gốc vào path để import
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

async def test_report():
    print("=== TESTING REPORT DIANOSTICS ===")
    
    # 1. Kiểm tra các biến môi trường
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    gemini_key = os.environ.get("GEMINI_API_KEY")
    webhook_url = os.environ.get("ODO_SHEET_WEBHOOK_URL")
    warn_chat_id = os.environ.get("WARN_CHAT_ID", "-1002712779761")
    odo_gid = os.environ.get("ODO_SHEET_GID")
    
    print(f"TELEGRAM_BOT_TOKEN: {'Đã cấu hình' if token else 'CHƯA CẤU HÌNH'}")
    if token:
        print(f"  - Token preview: {token[:10]}...")
    print(f"GEMINI_API_KEY: {'Đã cấu hình' if gemini_key else 'CHƯA CẤU HÌNH'}")
    if gemini_key:
        print(f"  - Key preview: {gemini_key[:10]}...")
    print(f"WARN_CHAT_ID: {warn_chat_id}")
    print(f"ODO_SHEET_GID: {odo_gid}")
    
    if not token:
        print("FAIL: Không có token bot. Bot không thể chạy.")
        return

    # 2. Thử import telegram_bot và gọi hàm
    try:
        from telegram_bot import get_gxt_vehicles_count, generate_odo_warning_report
        
        print("\n[1/3] Đang tải danh sách xe từ Google Sheet...")
        registered = get_gxt_vehicles_count()
        print(f"Số lượng kho xe đã đăng ký: {len(registered)}")
        for k, v in list(registered.items())[:3]:
            print(f"  - Kho {v['ten_kho']} (ID: {v['id_kho']}): {v['total_vehicles']} xe")
            
        print("\n[2/3] Đang thử sinh báo cáo ODO mẫu cho ngày hôm nay...")
        today_str = dt.datetime.now().strftime("%d/%m/%Y")
        report = generate_odo_warning_report(today_str, "Test")
        print("\n--- NỘI DUNG BÁO CÁO THỬ NGHIỆM ---")
        print(report[:800])
        print("----------------------------------")
        
        # 3. Thử gửi tin nhắn kiểm tra tới nhóm báo cáo
        print("\n[3/3] Đang thử gửi một tin nhắn test tới Telegram chat...")
        from telegram import Bot
        bot = Bot(token)
        me = await bot.get_me()
        print(f"Kết nối thành công tới bot: @{me.username}")
        
        await bot.send_message(
            chat_id=warn_chat_id,
            text=f"🔄 <b>TIN NHẮN CHẨN ĐOÁN HỆ THỐNG:</b>\nKết nối bot thành công. Báo cáo ODO đang hoạt động.",
            parse_mode="HTML"
        )
        print("SUCCESS: Đã gửi tin nhắn test thành công tới Telegram!")
        
    except Exception as e:
        import traceback
        print(f"\nFAIL: Đã xảy ra lỗi chẩn đoán: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_report())
