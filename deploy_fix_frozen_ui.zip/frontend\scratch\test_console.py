import time
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

# Enable console logging
caps = DesiredCapabilities.CHROME.copy()
caps['goog:loggingPrefs'] = {'browser': 'ALL'}

options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

try:
    driver = webdriver.Chrome(options=options)
    driver.get('http://127.0.0.1:8088/')
    time.sleep(3)
    
    # Extract logs
    print("=== BROWSER LOGS ===")
    for entry in driver.get_log('browser'):
        print(entry)
    driver.quit()
except Exception as e:
    print("Error running selenium:", e)
