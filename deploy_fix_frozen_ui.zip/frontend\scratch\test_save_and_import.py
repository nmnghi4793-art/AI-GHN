import sys, os, json, secrets
from datetime import datetime

sys.path.insert(0, '.')

from main import _load_xe_daily_records, _save_xe_daily_records, MASTER_30_XE_DAILY_RECORDS, XE_DAILY_META_FILE

# 1. Reset dataset to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
if os.path.exists(XE_DAILY_META_FILE):
    os.remove(XE_DAILY_META_FILE)

initial = _load_xe_daily_records()
print("1. Initial record count:", len(initial))
assert len(initial) == 30, f"Expected 30 records, got {len(initial)}"

# 2. Test saving manual record for Xe OFF (camelCase payload format)
payload_off = {
  "date": "23/07/2026",
  "warehouse": "Kho Giao Hàng Nặng - Thạch Linh - Hà Tĩnh",
  "recordType": "Xe không hoạt động",
  "vehicleCount": 1,
  "licensePlate": "50H-114.14",
  "vendor": "An Logistics",
  "payloadKg": 1400,
  "note": "Test Xe OFF camelCase"
}

# Normalize like main.py
now_iso = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
rec_off = {
    "id": secrets.token_hex(8),
    "ngay": payload_off["date"],
    "ten_kho": payload_off["warehouse"],
    "loai": payload_off["recordType"],
    "so_luong_xe": payload_off["vehicleCount"],
    "bien_so_xe": payload_off["licensePlate"],
    "ten_ncc": payload_off["vendor"],
    "trong_tai": payload_off["payloadKg"],
    "ghi_chu": payload_off["note"],
    "nguoi_nhap": "Tester OFF",
    "thoi_gian_ghi_nhan": now_iso
}
initial.append(rec_off)
_save_xe_daily_records(initial, sync_db=False)

after_off = _load_xe_daily_records()
print("2. Record count after adding Xe OFF:", len(after_off))
assert len(after_off) == 31

# 3. Test saving manual record for Xe Tăng Cường (snake_case payload format)
payload_tc = {
  "ngay": "23/07/2026",
  "ten_kho": "Kho Giao Hàng Nặng - Đà Nẵng",
  "loai": "Xe tăng cường",
  "so_luong_xe": 2,
  "bien_so_xe": "43C-999.88",
  "ten_ncc": "Bảo Châu Phát",
  "trong_tai": 2500,
  "ghi_chu": "Test Xe Tăng Cường snake_case"
}

rec_tc = {
    "id": secrets.token_hex(8),
    "ngay": payload_tc["ngay"],
    "ten_kho": payload_tc["ten_kho"],
    "loai": payload_tc["loai"],
    "so_luong_xe": payload_tc["so_luong_xe"],
    "bien_so_xe": payload_tc["bien_so_xe"],
    "ten_ncc": payload_tc["ten_ncc"],
    "trong_tai": payload_tc["trong_tai"],
    "ghi_chu": payload_tc["ghi_chu"],
    "nguoi_nhap": "Tester TC",
    "thoi_gian_ghi_nhan": now_iso
}
after_off.append(rec_tc)
_save_xe_daily_records(after_off, sync_db=False)

after_tc = _load_xe_daily_records()
print("3. Record count after adding Xe Tăng Cường:", len(after_tc))
assert len(after_tc) == 32

# 4. Clean up test records back to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
final_recs = _load_xe_daily_records()
print("4. Cleaned up record count:", len(final_recs))
assert len(final_recs) == 30

print("\nALL MANUAL SAVE & IMPORT TESTS PASSED 100%!")
