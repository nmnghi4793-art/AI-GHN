import os
import sys
import asyncio
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import odo_monitor
import telegram_odo
import odo_scheduler

async def run_manual_test():
    print("==========================================================================")
    print("MANUAL TEST FOR ODO MONITOR BOT (DATA DATE: 22/07/2026)")
    print("==========================================================================")

    target_date = "22/07/2026"
    print(f"\n1. Fetching ODO data for target date: {target_date}...")
    status_res = odo_monitor.calculate_odo_status(target_date, force_refresh=True)
    summary = status_res["summary"]
    details = status_res["details"]

    print("\n2. Detailed ODO Status Per Warehouse:")
    print(f"{'STT':<4} | {'Tên Kho':<45} | {'Phải Báo':<9} | {'Đã Báo':<8} | {'Trạng Thái':<10} | {'Lệch'}")
    print("-" * 90)

    for idx, item in enumerate(details, 1):
        kho_short = item["kho"].replace("Kho Giao Hàng Nặng - ", "").strip()
        print(f"{idx:<4} | {kho_short:<45} | {item['expected_odo']:<9} | {item['actual_odo']:<8} | {item['status']:<10} | {item['diff']}")

    print("\n3. Summary Metrics:")
    print(f"   - Tổng số kho: {summary['total_khos']}")
    print(f"   - Số kho ĐỦ: {summary['du_khos']}")
    print(f"   - Số kho THIẾU: {summary['thieu_khos']}")
    print(f"   - Tổng xe THIẾU: {summary['total_xe_thieu']} xe")
    print(f"   - Tổng xe THỪA: {summary['total_xe_thua']} xe")

    print("\n4. Projected Telegram Message:")
    msg_report = telegram_odo.build_odo_report_message({target_date: status_res}, slot_hour=18)
    print("--------------------------------------------------------------------------")
    print(msg_report if msg_report else "(No telegram message needed - All warehouses complete)")
    print("--------------------------------------------------------------------------")

    print("\n5. Testing Telegram Message Delivery...")
    if msg_report:
        sent_ok = await telegram_odo.send_telegram_message(msg_report)
        print(f"Telegram Delivery Result: {'SUCCESS (HTTP 200 OK)' if sent_ok else 'FAILED'}")
    else:
        print("Skipped sending empty message.")

    print("\n==========================================================================")
    print("MANUAL TEST COMPLETED SUCCESSFULLY!")
    print("==========================================================================")

if __name__ == "__main__":
    asyncio.run(run_manual_test())
