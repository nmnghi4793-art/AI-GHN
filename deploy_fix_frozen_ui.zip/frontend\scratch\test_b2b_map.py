from main import get_kho_gxt

kho_list = get_kho_gxt(force=True)
print(f"Total warehouses returned: {len(kho_list)}")
for i, item in enumerate(kho_list[:5]):
    print(f"[{i+1}] ID: {item.get('idKho')}, Name: {item.get('tenKho')}, Address: {item.get('diaChi')}")
    print(f"     Link GGM: {item.get('linkGGM') or item.get('googleMapsLink')}")
    print(f"     Coords: {item.get('coords')}")
    print(f"     mapStatus: {item.get('mapStatus')}")
