import os
import sys
import asyncio
from datetime import datetime, timedelta

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

import odo_monitor
import telegram_odo
import odo_scheduler
import main
from fastapi.testclient import TestClient

print("=====================================================")
print("RUNNING FULL AUTOMATED VERIFICATION FOR ODO MODULE")
print("=====================================================")

# 1. Test calculation engine
print("\n[1/5] Testing ODO Calculation Engine...")
status_today = odo_monitor.calculate_odo_status("22/07/2026", force_refresh=True)
summary = status_today["summary"]
print(f"Summary: Total Khos={summary['total_khos']}, Du={summary['du_khos']}, Thieu={summary['thieu_khos']}, Xe Thieu={summary['total_xe_thieu']}, Xe Thua={summary['total_xe_thua']}")
assert summary["total_khos"] > 0, "Error: Master warehouses count should be > 0"
print("✓ Calculation engine test PASSED!")

# 2. Test formula: expectedOdo = tongXe + xeTangCuong - xeOff
print("\n[2/5] Testing Formula (expectedOdo = tongXe + xeTangCuong - xeOff)...")
for item in status_today["details"][:5]:
    expected_calc = max(0, item["tong_xe"] + item["xe_tc"] - item["xe_off"])
    assert item["expected_odo"] == expected_calc, f"Formula error for {item['kho']}"
print("✓ Formula test PASSED!")

# 3. Test Telegram Message Builder
print("\n[3/5] Testing Telegram Message Formatting...")
msg_xe = telegram_odo.build_xe_van_hanh_message("22/07/2026")
print("Preview 18:00 XE VẬN HÀNH message length:", len(msg_xe))

msg_odo = telegram_odo.build_odo_report_message({"22/07/2026": status_today}, slot_hour=18)
assert "🚨 *BÁO CÁO ODO*" in msg_odo, "Telegram message missing header"
print("✓ Telegram message builder test PASSED!")

# 4. Test API Functions directly
print("\n[4/5] Testing API Functions...")
direct_status = main.get_odo_monitor_status(date="22/07/2026", force=False)
assert "summary" in direct_status, "Missing summary key in direct status response"

direct_logs = main.get_odo_monitor_logs()
assert direct_logs["status"] == "ok", "Logs API function failed"

print("✓ API functions test PASSED!")

# 5. Verify Zero Impact on Existing KPIs
print("\n[5/5] Verifying Zero Impact on Existing KPI Functions...")
xe_gxt_data, _ = main.read_csv("xe_gxt")
assert len(xe_gxt_data) > 0, "Existing xe_gxt broke!"

xe_su_co_data, _ = main.read_csv("xe_su_co")
assert len(xe_su_co_data) > 0, "Existing xe_su_co broke!"

xe_daily_records = main._load_xe_daily_records()
assert isinstance(xe_daily_records, list), "Existing _load_xe_daily_records broke!"

print("✓ Existing KPI verification PASSED!")

print("\n=====================================================")
print("ALL 5 AUTOMATED VERIFICATION TESTS PASSED SUCCESSFULLY!")
print("=====================================================")
