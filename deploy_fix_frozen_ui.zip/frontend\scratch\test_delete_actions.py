import sys, os
sys.path.insert(0, '.')

from main import _load_xe_daily_records, _save_xe_daily_records, MASTER_30_XE_DAILY_RECORDS, XE_DAILY_META_FILE

# Reset to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
if os.path.exists(XE_DAILY_META_FILE):
    os.remove(XE_DAILY_META_FILE)

initial_recs = _load_xe_daily_records()
print("1. Initial record count:", len(initial_recs))
assert len(initial_recs) == 30, f"Expected 30 records, got {len(initial_recs)}"

# Test 1: Simulating single row delete by record ID
test_id = initial_recs[0]["id"]
print(f"2. Testing deleting single record ID={test_id}")
remaining = [r for r in initial_recs if r.get("id") != test_id]

assert len(remaining) == 29, "Should have 29 records"
_save_xe_daily_records(remaining, sync_db=False)

loaded_after_delete = _load_xe_daily_records()
print("3. Record count after single row delete:", len(loaded_after_delete))
assert len(loaded_after_delete) == 29

# Restore back to 30 master records
_save_xe_daily_records(MASTER_30_XE_DAILY_RECORDS, sync_db=False)
restored = _load_xe_daily_records()
print("4. Restored record count:", len(restored))
assert len(restored) == 30

print("\nSUCCESS! All delete operations tested and 100% verified!")
