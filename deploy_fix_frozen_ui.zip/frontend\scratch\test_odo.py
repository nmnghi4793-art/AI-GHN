import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import odo_monitor

res = odo_monitor.calculate_odo_status('23/07/2026', force_refresh=True)
summary = res['summary']
details = res['details']

print('Summary:', summary)
print(f'Total Warehouses: {len(details)}')
print('\nSample Warehouses:')
for r in details[:6]:
    print(f"{r['kho']}: XeChuan={r['tong_xe']}, XeTC={r['xe_tc']}, XeOFF={r['xe_off']} -> PhaiBao={r['expected_odo']}, DaBao={r['actual_odo']}, Status={r['status']}, Diff={r['diff']}")
